# Nado Livre — Controle de Toalhas

## Identificação do grupo
- **Grupo:** preencher com os nomes dos integrantes.
- **Estudo de caso:** sistema de cadastro de nadadores, funcionários e toalhas, com controle de empréstimos e devoluções.

## O que o projeto implementa
- API REST simulada com **JSON Server** e dados iniciais no `db.json`.
- Módulo `frontend/api/api.js` centraliza `GET`, `POST`, `PUT`, `PATCH` e `DELETE`.
- Classes de domínio `Toalha` e `ToalhaManutencao` não constroem HTML.
- `frontend/interface/componentes.js` constrói os elementos visuais das toalhas.
- `frontend/app.js` conecta formulários, listagens e ações à API.
- CRUD de toalhas, nadadores e funcionários; alteração da permissão de retirada; criação de empréstimos e devoluções.
- Os empréstimos guardam os IDs relacionados (`idNadador`, `idFuncionario`, `idToalha`). A interface consulta os registros e avisa quando algum relacionamento não é encontrado.
- Tratamento de falhas de conexão e respostas HTTP malsucedidas.

## Requisitos
- Node.js e npm instalados.
- Visual Studio Code com a extensão Live Server (ou servidor estático equivalente).

## Instalação e execução
1. Abra o terminal na pasta raiz do projeto, onde está este `README.md`.
2. Instale as dependências:

   ```bash
   npm install
   ```

3. Inicie a API simulada:

   ```bash
   npx json-server --watch db.json --port 3000
   ```

   Alternativamente, após instalar as dependências, execute `npm start`.
4. No VS Code, abra `frontend/index.html` com **Live Server**. Não abra o HTML diretamente como arquivo local, pois o projeto utiliza módulos JavaScript.
5. A API ficará em `http://localhost:3000`. Recursos disponíveis:
   - `GET/POST /nadadores`
   - `GET/PUT/PATCH/DELETE /nadadores/:id`
   - `GET/POST /funcionarios`
   - `GET/PUT/DELETE /funcionarios/:id`
   - `GET/POST /toalhas`
   - `GET/PUT/DELETE /toalhas/:id`
   - `GET/POST /emprestimos`
   - `GET/PUT/DELETE /emprestimos/:id`

## Como testar (seção 7.9.6)
- **Listagem inicial:** ao abrir a página, confira toalhas, nadadores, funcionários e histórico.
- **Cadastro:** adicione uma toalha, um nadador e um funcionário; confirme que aparecem nas listas e em `db.json`.
- **Alteração:** edite uma toalha pelos botões; use “Editar” em nadadores e funcionários para atualizar seus dados.
- **Exclusão:** remova um registro e confirme que ele não aparece mais na listagem. A exclusão de toalhas com empréstimos em aberto é bloqueada.
- **Relacionamentos:** registre empréstimo e confira os IDs de nadador, funcionário e toalha no recurso `emprestimos`; faça a devolução e confirme a mudança do status da toalha.
- **Registro relacionado ausente:** para simular, remova manualmente do `db.json` um nadador/funcionário/toalha que esteja referenciado por um empréstimo e reinicie o JSON Server. O histórico deve informar que o cadastro relacionado não foi encontrado.
- **Servidor indisponível:** pare o JSON Server e recarregue a interface. A mensagem de conexão deverá explicar que o servidor não está disponível.
- **Resposta HTTP malsucedida:** na aba Network, teste uma URL de recurso inexistente (por exemplo, `http://localhost:3000/nadadores/99999`) para observar o status HTTP. A aplicação também trata respostas não-OK no módulo `api.js`.

## Ferramentas de verificação
Abra as ferramentas do navegador (`F12`) e use **Console** e **Network** para observar erros, URLs, métodos HTTP, corpos enviados e respostas. O JSON Server é uma API de estudo: regras de negócio do empréstimo são verificadas pela interface; em produção, também devem ser validadas no backend.

## Observação sobre a API Flask
A pasta `api/` da versão anterior do projeto foi mantida como referência. Para esta atividade do capítulo 7.9, siga os comandos de JSON Server acima, que usam o `db.json` na raiz e a URL `http://localhost:3000`.
