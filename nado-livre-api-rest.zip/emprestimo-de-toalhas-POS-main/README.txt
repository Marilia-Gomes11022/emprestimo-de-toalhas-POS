Nado Livre — Controle de Toalhas

Para instalar: npm install
Para iniciar a API: npx json-server --watch db.json --port 3000 (ou npm start)
Depois abra frontend/index.html com a extensão Live Server do VS Code.
Leia README.md para instruções completas, recursos da API e roteiro de testes.
