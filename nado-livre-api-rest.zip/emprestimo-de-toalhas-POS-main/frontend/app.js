import { api, ApiError } from "./api/api.js";
import { Toalha } from "./classes/Toalha.js";
import { ToalhaManutencao } from "./classes/ToalhaManutencao.js";
import { criarItemToalha, criarCelula } from "./interface/componentes.js";

let nadadores = [], funcionarios = [], toalhas = [], emprestimos = [];
const $ = (seletor) => document.querySelector(seletor);
const listaToalhas = $("#lista-toalhas"), dialogo = $("#dialogo-toalha"), formToalha = $("#form-toalha");
const campoId = $("#campo-id"), campoCodigo = $("#campo-codigo"), campoTamanho = $("#campo-tamanho"), campoStatus = $("#campo-status"), campoTipo = $("#campo-tipo"), campoObservacao = $("#campo-observacao"), rotuloObservacao = $("#rotulo-observacao");

function mensagem(texto, tipo = "sucesso") {
  const el = $("#mensagem-emprestimo");
  el.textContent = texto; el.className = `mensagem ${tipo}`;
}
function erroAmigavel(erro) {
  if (erro instanceof ApiError) {
    if (erro.status === 404) return "O registro solicitado não foi encontrado. A lista será atualizada.";
    if (erro.status >= 400) return `O servidor recusou a operação (${erro.status}): ${erro.message}`;
    return erro.message;
  }
  return "Ocorreu um erro inesperado. Confira os dados e tente novamente.";
}
async function executar(acao, sucesso) {
  try { await acao(); await carregarDados(); if (sucesso) mensagem(sucesso); }
  catch (erro) { console.error(erro); mensagem(erroAmigavel(erro), "erro"); }
}
async function carregarDados() {
  // Requisições separadas facilitam identificar no DevTools qual recurso falhou.
  [nadadores, funcionarios, toalhas, emprestimos] = await Promise.all([
    api.listar("nadadores"), api.listar("funcionarios"), api.listar("toalhas"), api.listar("emprestimos")
  ]);
  toalhas = toalhas.map(t => t.tipo === "manutencao" ? new ToalhaManutencao(t) : new Toalha(t));
  renderTudo();
}
function acharNadador(id) { return nadadores.find(n => Number(n.id) === Number(id)); }
function acharFuncionario(id) { return funcionarios.find(f => Number(f.id) === Number(id)); }
function acharToalha(id) { return toalhas.find(t => Number(t.id) === Number(id)); }
function dataLocal(valor) { if (!valor) return "—"; const d = new Date(valor); return Number.isNaN(d.getTime()) ? valor : d.toLocaleString("pt-BR"); }
function preencherTabela(corpo, registros, colunas, vazio, acoes = true) {
  corpo.replaceChildren();
  if (!registros.length) { const tr = document.createElement("tr"), td = criarCelula(vazio); td.colSpan = colunas.length + (acoes ? 1 : 0); td.className = "vazio"; tr.append(td); corpo.append(tr); return; }
  registros.forEach(registro => {
    const tr = document.createElement("tr");
    colunas.forEach(coluna => tr.append(criarCelula(coluna(registro))));
    if (acoes) {
      const td = document.createElement("td");
      const editar = document.createElement("button"); editar.type = "button"; editar.className = "btn primary"; editar.textContent = "Editar"; editar.dataset.editar = registro.id;
      const excluir = document.createElement("button"); excluir.type = "button"; excluir.className = "btn danger"; excluir.textContent = "Excluir"; excluir.dataset.excluir = registro.id;
      td.append(editar, document.createTextNode(" "), excluir); tr.append(td);
    }
    corpo.append(tr);
  });
}
function renderToalhas() {
  listaToalhas.replaceChildren();
  if (!toalhas.length) { listaToalhas.append(criarCelula("Nenhuma toalha cadastrada.")); return; }
  toalhas.forEach(t => listaToalhas.append(criarItemToalha(t)));
}
function renderNadadores() {
  const corpo = $("#lista-nadadores"); corpo.replaceChildren();
  if (!nadadores.length) { const tr = document.createElement("tr"), td = criarCelula("Nenhum nadador cadastrado."); td.colSpan = 5; tr.append(td); corpo.append(tr); return; }
  nadadores.forEach(n => {
    const tr = document.createElement("tr");
    tr.append(criarCelula(n.nome), criarCelula(n.documento), criarCelula(n.turma));
    const tdPerm = document.createElement("td"), selo = document.createElement("span"); selo.className = `permissao ${n.podeRetirarToalhas ? "permitido" : "bloqueado"}`; selo.textContent = n.podeRetirarToalhas ? "Autorizado" : "Sem permissão"; tdPerm.append(selo); tr.append(tdPerm);
    const tdAcoes = document.createElement("td"), perm = document.createElement("button"); perm.type = "button"; perm.className = `btn ${n.podeRetirarToalhas ? "danger" : "success"}`; perm.dataset.permissao = n.id; perm.textContent = n.podeRetirarToalhas ? "Retirar permissão" : "Conceder permissão";
    const editar = document.createElement("button"); editar.type = "button"; editar.className = "btn primary"; editar.dataset.editar = n.id; editar.textContent = "Editar";
    const excluir = document.createElement("button"); excluir.type = "button"; excluir.className = "btn danger"; excluir.dataset.excluir = n.id; excluir.textContent = "Excluir";
    tdAcoes.append(perm, document.createTextNode(" "), editar, document.createTextNode(" "), excluir); tr.append(tdAcoes); corpo.append(tr);
  });
}
function renderFuncionarios() {
  preencherTabela($("#lista-funcionarios"), funcionarios, [f => f.nome, f => f.matricula, f => f.cargo], "Nenhum funcionário cadastrado.");
}
function renderSelects() {
  const fSel = $("#emprestimo-funcionario"), nSel = $("#emprestimo-nadador"), tSel = $("#emprestimo-toalha");
  const anterior = [fSel.value, nSel.value, tSel.value];
  const preencher = (select, itens, texto, vazio) => {
    select.replaceChildren();
    if (!itens.length) { const op = document.createElement("option"); op.value = ""; op.textContent = vazio; select.append(op); return; }
    itens.forEach(item => { const op = document.createElement("option"); op.value = item.id; op.textContent = texto(item); select.append(op); });
  };
  preencher(fSel, funcionarios, f => `${f.nome} — ${f.matricula}`, "Cadastre um funcionário primeiro");
  preencher(nSel, nadadores, n => `${n.nome}${n.podeRetirarToalhas ? " — autorizado" : " — sem permissão"}`, "Cadastre um nadador primeiro");
  preencher(tSel, toalhas.filter(t => t.status === "disponivel"), t => `${t.codigo} (${t.tamanho})`, "Nenhuma toalha disponível");
  [fSel, nSel, tSel].forEach((s, i) => { if ([...s.options].some(o => o.value === anterior[i])) s.value = anterior[i]; });
}
function renderEmprestimos() {
  const corpo = $("#lista-emprestimos"); corpo.replaceChildren();
  const ordenados = [...emprestimos].sort((a,b) => new Date(b.dataHoraRetirada) - new Date(a.dataHoraRetirada));
  if (!ordenados.length) { const tr = document.createElement("tr"), td = criarCelula("Nenhum empréstimo registrado."); td.colSpan = 5; tr.append(td); corpo.append(tr); return; }
  ordenados.forEach(m => {
    const n = acharNadador(m.idNadador), t = acharToalha(m.idToalha), f = acharFuncionario(m.idFuncionario);
    const tr = document.createElement("tr");
    tr.append(criarCelula(n ? n.nome : `Nadador não encontrado (ID ${m.idNadador})`), criarCelula(t ? t.codigo : `Toalha não encontrada (ID ${m.idToalha})`), criarCelula(dataLocal(m.dataHoraRetirada)), criarCelula(dataLocal(m.dataHoraDevolucao)));
    const td = document.createElement("td");
    if (!m.dataHoraDevolucao) { const b = document.createElement("button"); b.type = "button"; b.className = "btn primary"; b.dataset.devolver = m.id; b.textContent = "Registrar devolução"; td.append(b); }
    else td.append(document.createTextNode("Devolvido"));
    if (!n || !t || !f) { const aviso = document.createElement("small"); aviso.className = "meta"; aviso.textContent = "Relacionamento incompleto"; td.append(document.createTextNode(" "), aviso); }
    tr.append(td); corpo.append(tr);
  });
}
function renderTudo() { renderToalhas(); renderNadadores(); renderFuncionarios(); renderSelects(); renderEmprestimos(); }
function atualizarCamposTipo() { const manutencao = campoTipo.value === "manutencao"; rotuloObservacao.hidden = !manutencao; if (manutencao) campoStatus.value = "manutencao"; }
function abrirCriacao() { formToalha.reset(); campoId.value = ""; $("#titulo-dialogo").textContent = "Adicionar toalha"; $("#btn-salvar").textContent = "Adicionar"; campoTipo.value = "comum"; campoStatus.value = "disponivel"; atualizarCamposTipo(); dialogo.showModal(); }
function abrirEdicao(id) { const t = acharToalha(id); if (!t) { mensagem("Toalha não encontrada.", "erro"); return; } $("#titulo-dialogo").textContent = "Editar toalha"; $("#btn-salvar").textContent = "Salvar"; campoId.value = t.id; campoCodigo.value = t.codigo; campoTamanho.value = t.tamanho; campoStatus.value = t.status; campoTipo.value = t.tipo; campoObservacao.value = t.observacao || ""; atualizarCamposTipo(); dialogo.showModal(); }

// Navegação dos painéis.
document.querySelectorAll("[data-painel]").forEach(botao => botao.addEventListener("click", () => {
  document.querySelectorAll("[data-painel]").forEach(b => { b.classList.toggle("success", b === botao); b.classList.toggle("default", b !== botao); });
  document.querySelectorAll(".painel").forEach(p => p.classList.toggle("ativo", p.id === botao.dataset.painel));
}));
$("#btn-nova").addEventListener("click", abrirCriacao); $("#btn-cancelar").addEventListener("click", () => dialogo.close()); campoTipo.addEventListener("change", atualizarCamposTipo);
formToalha.addEventListener("submit", async evento => {
  evento.preventDefault(); const id = campoId.value ? Number(campoId.value) : null;
  const dados = { codigo: campoCodigo.value.trim(), tamanho: campoTamanho.value, status: campoTipo.value === "manutencao" ? "manutencao" : campoStatus.value, tipo: campoTipo.value, observacao: campoTipo.value === "manutencao" ? campoObservacao.value.trim() : "" };
  if (!dados.codigo) return;
  if (toalhas.some(t => t.codigo.toLowerCase() === dados.codigo.toLowerCase() && Number(t.id) !== id)) { alert("Já existe uma toalha com esse código."); return; }
  await executar(async () => { if (id === null) await api.criar("toalhas", dados); else await api.atualizar("toalhas", id, { id, ...dados }); dialogo.close(); }, id === null ? "Toalha cadastrada." : "Toalha atualizada.");
});
listaToalhas.addEventListener("click", async evento => {
  const botao = evento.target.closest("button[data-acao]"); if (!botao) return; const id = Number(botao.closest("[data-id]")?.dataset.id); if (!id) return;
  if (botao.dataset.acao === "editar") abrirEdicao(id);
  if (botao.dataset.acao === "remover" && confirm("Deseja remover esta toalha?")) {
    if (emprestimos.some(m => Number(m.idToalha) === id && !m.dataHoraDevolucao)) { mensagem("Não é possível excluir toalha com empréstimo em aberto.", "erro"); return; }
    await executar(() => api.excluir("toalhas", id), "Toalha excluída.");
  }
});

$("#form-nadador").addEventListener("submit", async evento => {
  evento.preventDefault(); const dados = { nome: $("#nadador-nome").value.trim(), documento: $("#nadador-documento").value.trim(), turma: $("#nadador-turma").value.trim(), podeRetirarToalhas: $("#nadador-permissao").checked };
  if (nadadores.some(n => n.documento.toLowerCase() === dados.documento.toLowerCase())) { alert("Já existe um nadador com esse documento."); return; }
  await executar(async () => { await api.criar("nadadores", dados); evento.target.reset(); $("#nadador-permissao").checked = true; }, "Nadador cadastrado.");
});
$("#lista-nadadores").addEventListener("click", async evento => {
  const b = evento.target.closest("button"); if (!b) return; const id = Number(b.dataset.permissao || b.dataset.editar || b.dataset.excluir); if (!id) return;
  const n = acharNadador(id); if (!n) { mensagem("Nadador não encontrado.", "erro"); return; }
  if (b.dataset.permissao) await executar(() => api.atualizarParcial("nadadores", id, { podeRetirarToalhas: !n.podeRetirarToalhas }), "Permissão atualizada.");
  if (b.dataset.editar) {
    const nome = prompt("Nome do nadador:", n.nome); if (nome === null) return;
    const documento = prompt("Documento:", n.documento); if (documento === null) return;
    const turma = prompt("Turma:", n.turma); if (turma === null) return;
    await executar(() => api.atualizar("nadadores", id, { ...n, nome: nome.trim(), documento: documento.trim(), turma: turma.trim() }), "Nadador atualizado.");
  }
  if (b.dataset.excluir && confirm("Excluir este nadador? O histórico de empréstimos será preservado; os relacionamentos passarão a indicar cadastro ausente.")) await executar(() => api.excluir("nadadores", id), "Nadador excluído.");
});

$("#form-funcionario").addEventListener("submit", async evento => {
  evento.preventDefault(); const dados = { nome: $("#funcionario-nome").value.trim(), matricula: $("#funcionario-matricula").value.trim(), cargo: $("#funcionario-cargo").value.trim() };
  if (funcionarios.some(f => f.matricula.toLowerCase() === dados.matricula.toLowerCase())) { alert("Já existe um funcionário com essa matrícula."); return; }
  await executar(async () => { await api.criar("funcionarios", dados); evento.target.reset(); }, "Funcionário cadastrado.");
});
$("#lista-funcionarios").addEventListener("click", async evento => {
  const b = evento.target.closest("button"); if (!b) return; const id = Number(b.dataset.editar || b.dataset.excluir); if (!id) return;
  const f = acharFuncionario(id); if (!f) { mensagem("Funcionário não encontrado.", "erro"); return; }
  if (b.dataset.editar) {
    const nome = prompt("Nome do funcionário:", f.nome); if (nome === null) return;
    const matricula = prompt("Matrícula:", f.matricula); if (matricula === null) return;
    const cargo = prompt("Cargo:", f.cargo); if (cargo === null) return;
    await executar(() => api.atualizar("funcionarios", id, { ...f, nome: nome.trim(), matricula: matricula.trim(), cargo: cargo.trim() }), "Funcionário atualizado.");
  }
  if (b.dataset.excluir && confirm("Excluir funcionário? O histórico será mantido e mostrará o relacionamento ausente.")) await executar(() => api.excluir("funcionarios", id), "Funcionário excluído.");
});

$("#form-emprestimo").addEventListener("submit", async evento => {
  evento.preventDefault(); const idFuncionario = Number($("#emprestimo-funcionario").value), idNadador = Number($("#emprestimo-nadador").value), idToalha = Number($("#emprestimo-toalha").value);
  const f = acharFuncionario(idFuncionario), n = acharNadador(idNadador), t = acharToalha(idToalha);
  if (!f || !n || !t) { mensagem("Não foi possível localizar funcionário, nadador ou toalha. Atualize os dados e tente novamente.", "erro"); return; }
  if (!n.podeRetirarToalhas) { mensagem("Empréstimo bloqueado: este nadador está sem permissão.", "erro"); return; }
  if (t.status !== "disponivel") { mensagem("Esta toalha não está disponível.", "erro"); return; }
  await executar(async () => {
    const emprestimo = await api.criar("emprestimos", { idFuncionario, idNadador, idToalha, dataHoraRetirada: new Date().toISOString(), dataHoraDevolucao: null });
    await api.atualizar("toalhas", idToalha, { ...t, status: "em_uso" });
  }, `Empréstimo registrado para ${n.nome}.`);
});
$("#lista-emprestimos").addEventListener("click", async evento => {
  const b = evento.target.closest("button[data-devolver]"); if (!b) return; const m = emprestimos.find(x => Number(x.id) === Number(b.dataset.devolver));
  if (!m || m.dataHoraDevolucao) return;
  const t = acharToalha(m.idToalha); if (!t) { mensagem("A toalha relacionada não foi encontrada. Não foi possível registrar a devolução.", "erro"); return; }
  await executar(async () => { await api.atualizar("emprestimos", m.id, { ...m, dataHoraDevolucao: new Date().toISOString() }); await api.atualizar("toalhas", t.id, { ...t, status: "disponivel" }); }, "Devolução registrada.");
});

(async () => {
  try { await carregarDados(); mensagem("Dados carregados da API REST."); }
  catch (erro) { console.error(erro); mensagem(erroAmigavel(erro), "erro"); }
})();
