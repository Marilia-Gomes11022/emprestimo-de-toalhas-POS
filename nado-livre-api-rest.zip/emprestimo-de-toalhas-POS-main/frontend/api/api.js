const BASE_URL = "http://localhost:3000";

export class ApiError extends Error {
  constructor(message, status = 0) { super(message); this.name = "ApiError"; this.status = status; }
}

export async function requisicao(recurso, opcoes = {}) {
  let resposta;
  try {
    resposta = await fetch(`${BASE_URL}/${recurso}`, {
      ...opcoes,
      headers: { "Content-Type": "application/json", ...(opcoes.headers || {}) }
    });
  } catch {
    throw new ApiError("Não foi possível conectar ao servidor. Confira se o JSON Server está executando.");
  }
  if (!resposta.ok) {
    let detalhe = `Erro HTTP ${resposta.status}`;
    try { const corpo = await resposta.json(); detalhe = corpo.message || corpo.erro || detalhe; } catch { /* resposta sem JSON */ }
    throw new ApiError(detalhe, resposta.status);
  }
  if (resposta.status === 204) return null;
  const texto = await resposta.text();
  return texto ? JSON.parse(texto) : null;
}

export const api = {
  listar: (recurso) => requisicao(recurso),
  buscar: (recurso, id) => requisicao(`${recurso}/${id}`),
  criar: (recurso, dados) => requisicao(recurso, { method: "POST", body: JSON.stringify(dados) }),
  atualizar: (recurso, id, dados) => requisicao(`${recurso}/${id}`, { method: "PUT", body: JSON.stringify(dados) }),
  atualizarParcial: (recurso, id, dados) => requisicao(`${recurso}/${id}`, { method: "PATCH", body: JSON.stringify(dados) }),
  excluir: (recurso, id) => requisicao(`${recurso}/${id}`, { method: "DELETE" })
};
