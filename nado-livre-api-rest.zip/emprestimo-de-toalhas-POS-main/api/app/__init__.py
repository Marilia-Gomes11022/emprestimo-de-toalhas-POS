from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect, text
import os

db = SQLAlchemy()


def create_app():
    app = Flask(__name__)
    base = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(base, "toalhas.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    CORS(app)
    db.init_app(app)

    from app.routes import bp

    app.register_blueprint(bp)

    with app.app_context():
        db.create_all()
        # db.create_all() nao adiciona colunas em bancos que ja existiam.
        colunas = {coluna["name"] for coluna in inspect(db.engine).get_columns("nadadores")}
        if "pode_retirar_toalhas" not in colunas:
            with db.engine.begin() as conexao:
                conexao.execute(text(
                    "ALTER TABLE nadadores ADD COLUMN pode_retirar_toalhas BOOLEAN NOT NULL DEFAULT 1"
                ))

    return app
